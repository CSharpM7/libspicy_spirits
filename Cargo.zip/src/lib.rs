#![feature(
    concat_idents,
    proc_macro_hygiene
)]
#![allow(
    non_snake_case,
    unused
)]
#![allow(warnings)]
#![deny(
    deprecated
)]

//#[macro_use]
//extern crate lazy_static;

/*
mod imports;
pub mod spirits;
pub mod util;
mod system;
*/

#[skyline::main(name = "libspicy_spirits")]
pub fn main() {
    //system::install();
    println!("HUH");
}